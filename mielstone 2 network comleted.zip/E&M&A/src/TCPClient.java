import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class TCPClient {
	public static void main(String args[]) throws UnknownHostException,IOException
    { 
		String name,temp;
		//The client opens a socket connection with the server by typing the word 'CONNECT'
		// The socket should not be opened otherwise 
		//those are done .. :)
         Scanner sc= new Scanner (System.in);
         System.out.println("Enter connect word");
         String connection=sc.next();
         if(connection.equalsIgnoreCase("connect")) {
        	 Socket s = new Socket ("127.0.0.1",1342); //server ip , port number .. 
        	 // port number donot need to be changed 
        	 // server ip need to behh changed to be the ip adderes of the pc containing server 
        	 Scanner sc1 = new Scanner (s.getInputStream());
             System.out.println("Enter any word");
             name=sc.next();
             PrintStream p = new PrintStream(s.getOutputStream());
             p.println(name);
             temp=sc1.next();
             System.out.println(temp);
         }
         
         
         else {
                 System.out.println("you must type connect word");
                 System.out.println("code is terminated");
         
          }
         
         }

}
