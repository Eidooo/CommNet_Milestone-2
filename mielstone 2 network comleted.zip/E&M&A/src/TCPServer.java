import java.io.*; 
import java.net.*;
import java.util.Scanner; 

public class TCPServer {
	public static void main(String argv[]) throws IOException 
    { 
      
      String name;//,temp;
      String chat;
      ServerSocket s1= new ServerSocket(1341);
      System.out.println("Enter connect word");
      Scanner sc2= new Scanner (System.in);
      String connection=sc2.next();
      if(connection.equalsIgnoreCase("connect")) {
    	  System.out.println("Enter any word in server side");
      Socket ss = s1.accept();
      Scanner sc = new Scanner (ss.getInputStream());
      name=sc.next();
      System.out.println(name);
      
     // temp=name.toUpperCase();
      chat=sc.next();
      PrintStream p= new PrintStream (ss.getOutputStream());
      p.println(chat);
      
}
      else {
          System.out.println("you must type connect word");
          System.out.println("code is terminated");
  
   }
      
    
    }
	



}
